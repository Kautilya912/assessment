import React from 'react';
import '../components/ticket.css'

const Ticket = ({ ticket }) => {
  console.log("normal ticket--->", ticket)
    // {ticket.Todo.map((ak)=>{
      // console.log("ticket todo--->",ak)
  return (
    <div key={ticket.id} className="ticket">
      <p>{ticket.id}</p>
      <h5>{ticket.title}</h5>
      <p>Status: {ticket.status}</p>
      <p>User: {ticket.userId}</p>
      <p>Priority: {ticket.priority}</p>
    </div>
  );
// })}
};

export default Ticket;
