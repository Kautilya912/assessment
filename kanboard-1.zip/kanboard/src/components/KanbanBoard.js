import React from 'react';
import Ticket from './Ticket';

const KanbanBoard = ({ tickets }) => {
  console.log("noraml kanboard--->",tickets)
  return (
    <div className="kanban-board">
      {tickets.Backlog?.map((ticket) => (
        // console.log("kanboard ticket",ticket),
        <Ticket key={ticket.id} ticket={ticket} />
      ))}
    </div>
  );
};

export default KanbanBoard;
