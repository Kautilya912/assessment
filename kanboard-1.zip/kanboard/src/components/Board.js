import React, { useState, useEffect } from 'react';
import TicketCard from '../components/TicketCard';

const Board = ({ tickets }) => {
  const [sortedTickets, setSortedTickets] = useState(tickets);

  useEffect(() => {
    const savedSort = localStorage.getItem('sort');
    if (savedSort === 'priority') {
      sortByPriority();
    } else if (savedSort === 'title') {
      sortByTitle();
    }
  }, []); // Run once on component mount

  const sortByPriority = () => {
    const sorted = [...tickets].sort((a, b) => b.priority - a.priority);
    setSortedTickets(sorted);
    localStorage.setItem('sort', 'priority');
  };

  const sortByTitle = () => {
    const sorted = [...tickets].sort((a, b) => a.title.localeCompare(b.title));
    setSortedTickets(sorted);
    localStorage.setItem('sort', 'title');
  };

  return (
    <div className="board">
      <button onClick={sortByPriority}>Sort by Priority</button>
      <button onClick={sortByTitle}>Sort by Title</button>
      {sortedTickets.map(ticket => (
        <TicketCard key={ticket.id} ticket={ticket} />
      ))}
    </div>
  );
};

export default Board;
