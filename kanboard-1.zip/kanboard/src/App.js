import React, { useState, useEffect } from 'react';
import axios from 'axios';
import KanbanBoard from './components/KanbanBoard';

const App = () => {
  const [tickets, setTickets] = useState([]);
  const [groupingOption, setGroupingOption] = useState('status');
  const [sortingOption, setSortingOption] = useState('priority');

  useEffect(() => {
    axios.get('https://api.quicksell.co/v1/internal/frontend-assignment')
      .then((response) => {
        let groupedTickets = {};

        console.log("reeee--->", response)
        if (groupingOption === 'status') {
          groupedTickets = response.data.tickets.reduce((grouped, ticket) => {
            const status = ticket.status;
            if (!grouped[status]) {
              grouped[status] = [];
            }
            grouped[status].push(ticket);
            return grouped;
          }, {});
        } else if (groupingOption === 'user') {
          groupedTickets = response.data.tickets.reduce((grouped, ticket) => {
            const user = ticket.user;
            if (!grouped[user]) {
              grouped[user] = [];
            }
            grouped[user].push(ticket);
            return grouped;
          }, {});
        } else if (groupingOption === 'priority') {
          groupedTickets = response.data.tickets.reduce((grouped, ticket) => {
            const priority = ticket.priority;
            if (!grouped[priority]) {
              grouped[priority] = [];
            }
            grouped[priority].push(ticket);
            return grouped;
          }, {});
        }

       
        Object.keys(groupedTickets).forEach((key) => {
          if (sortingOption === 'priority') {
            groupedTickets[key].sort((a, b) => b.priority - a.priority);
          } else if (sortingOption === 'title') {
            groupedTickets[key].sort((a, b) => a.title.localeCompare(b.title));
          }
        });

        setTickets(groupedTickets);
      })
      .catch((error) => {
        console.error(error);
      });
  }, [groupingOption, sortingOption]); 

  return (
    <div className="app">
        
      <div className="options">
        
        <label>Group By:</label>
        <select
          value={groupingOption}
          onChange={(e) => setGroupingOption(e.target.value)}
        >
          <option value="status">Status</option>
          <option value="user">User</option>
          <option value="priority">Priority</option>
        </select>

        
        <label>Sort By:</label>
        <select
          value={sortingOption}
          onChange={(e) => setSortingOption(e.target.value)}
        >
          <option value="priority">Priority</option>
          <option value="title">Title</option>
        </select>
      </div>
      <KanbanBoard tickets={tickets} />
    </div>
  );
};

export default App;
